package com.example.business_bridge;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
