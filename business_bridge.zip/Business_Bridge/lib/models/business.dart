class Business {
  const Business({
    required this.id,
    required this.categories,

  });

  final String id;
  final List<String> categories;

}

