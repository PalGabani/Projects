class knowMore {
  const knowMore({
    required this.id,

    required this.title,
    required this.details,
    required this.title1,
    required this.title1des,
    required this.title2,
    required this.title2des,
    required this.title3,
    required this.title3des,
    required this.title4,
    required this.title4des,
    required this.title5,
    required this.title5des,
    required this.title6,
    required this.title6des,
    required this.title7,
    required this.title7des,
    required this.title8,
    required this.title8des,
    required this.title9,
    required this.title9des,
    required this.title10,
    required this.title10des,
    required this.title11,
    required this.title11des,
  });

  final String id;

  final String title;
  //final String imageUrl;

  final List<String> details;

  final String title1;
  final String title2;
  final String title3;
  final String title4;
  final String title5;
  final String title6;
  final String title7;
  final String title8;
  final String title9;
  final String title10;
  final String title11;

  final List<String> title1des;
  final List<String> title2des;
  final List<String> title3des;
  final List<String> title4des;
  final List<String> title5des;
  final List<String> title6des;
  final List<String> title7des;
  final List<String> title8des;
  final List<String> title9des;
  final List<String> title10des;
  final List<String> title11des;
}